Dataset description -
A folder with the name twitter_testX_seenval contains data for a setup with test topic X.
twitter_testX_seenval contains train, validation and test data files where the train data file includes labeled tweets for train topics and unlabeled tweets for the test topic X.
